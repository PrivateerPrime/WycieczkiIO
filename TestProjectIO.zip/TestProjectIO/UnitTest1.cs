using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WycieczkiIO.Controllers;
using WycieczkiIO.Data;
using WycieczkiIO.Models;
using Xunit;


namespace TestProjectIO
{

    public class UnitTest1
    {
        private MyDbContext _context = new(new DbContextOptions<MyDbContext>());
        
        [Fact]
        public void TestyAdresy()
        {
            var adresList = _context.Adres.ToList();
            
            Assert.Equal("Rue Cadet", adresList[0].Ulica);
            Assert.Equal("via Rome", adresList[1].Ulica);
            
            Assert.Equal(42, adresList[0].Numer);
            Assert.Equal(12, adresList[1].Numer);
            
            Assert.Equal("75009", adresList[0].KodPocztowy);
            Assert.Equal("12345", adresList[1].KodPocztowy);
            
            Assert.Equal(1, adresList[0].MiastoId);
            Assert.Equal(2, adresList[1].MiastoId);
            
            Assert.Equal(1, adresList[0].KrajId);
            Assert.Equal(2, adresList[1].KrajId);
        }
        
        [Fact]
        public void TestyAtrakcje()
        {
            var atrakcjaList = _context.Atrakcja.ToList();
            
            Assert.Equal("Wycieczka po Paryżu", atrakcjaList[0].Nazwa);
            Assert.Equal("Oprowadzenie po Rzymie", atrakcjaList[1].Nazwa);
            
            Assert.Equal(1, atrakcjaList[0].PrzewodnikId);
            Assert.Equal(1, atrakcjaList[1].PrzewodnikId);
        }

        [Fact]
        public void TestyKraje()
        {
            var krajList = _context.Kraj.ToList();
            
            Assert.Equal(1, krajList[0].KrajId);
            Assert.Equal(2, krajList[1].KrajId);
            
            Assert.Equal("Francja", krajList[0].NazwaKraju);
            Assert.Equal("Włochy", krajList[1].NazwaKraju);
        }
        
        [Fact]
        public void TestyMiasta()
        {
            var miastoList = _context.Miasto.ToList();
            
            Assert.Equal(1, miastoList[0].MiastoId);
            Assert.Equal(2, miastoList[1].MiastoId);
            
            Assert.Equal("Paryż", miastoList[0].NazwaMiasta);
            Assert.Equal("Rzym", miastoList[1].NazwaMiasta);
        }

        [Fact]
        public void TestyPlatnosci()
        {
            var platnoscList = _context.Platnosc.ToList();
            
            Assert.Equal(8, platnoscList[0].PlatnoscId);
            Assert.Equal(0, platnoscList[0].Kwota);
            Assert.Equal(0, platnoscList[0].Rabat);
            Assert.Equal(Status.Niezaplacona, platnoscList[0].Status);
        }

        [Fact]
        public void TestyPrzewodnicy()
        {
            var przewodnicyList = _context.Przewodnik.ToList();
            
            Assert.Equal(1, przewodnicyList[0].PrzewodnikId);
            Assert.Equal("Inspektor", przewodnicyList[0].Imie);
            Assert.Equal("Gadżet", przewodnicyList[0].Nazwisko);
            Assert.Equal("123456789", przewodnicyList[0].Telefon);
        }
        
        [Fact]
        public void TestyUczestnicy()
        {
            var uczestnicyList = _context.Uczestnik.ToList();
            
            Assert.Equal(4, uczestnicyList[0].UczestnikId);
            Assert.Equal(6, uczestnicyList[1].UczestnikId);
            
            Assert.Equal("Jan", uczestnicyList[0].Imie);
            Assert.Equal("Jan", uczestnicyList[1].Imie);
            
            Assert.Equal("Kowalski", uczestnicyList[0].Nazwisko);
            Assert.Equal("Nowak", uczestnicyList[1].Nazwisko);
            
            Assert.Equal("61654981989", uczestnicyList[0].Pesel);
            Assert.Equal("1651", uczestnicyList[1].Pesel);
            
            Assert.Equal("12345678901", uczestnicyList[0].Telefon);
            Assert.Null(uczestnicyList[1].Telefon);
            
            Assert.Equal("temp@temp.pl", uczestnicyList[0].Email);
            Assert.Equal("JanNowak@gmail.com", uczestnicyList[1].Email);
            
            Assert.Equal(7, uczestnicyList[0].WycieczkaId);
            Assert.Equal(7, uczestnicyList[1].WycieczkaId);
        }

        [Fact]
        public void TestyWycieczka()
        {
            var wycieczkaList = _context.Wycieczka.ToList();
            
            Assert.Equal(7, wycieczkaList[0].WycieczkaId);
            Assert.Equal(new DateTime(2022,01,21), wycieczkaList[0].DataRozpoczecia);
            Assert.Equal(new DateTime(2022,01,28), wycieczkaList[0].DataZakonczenia);
            Assert.Equal(StatusWycieczki.Aktywna, wycieczkaList[0].Status);
            Assert.Equal("Paryż", wycieczkaList[0].MiejsceDocelowe);
            Assert.Equal(8, wycieczkaList[0].PlatnoscId);
            Assert.Null(wycieczkaList[0].ZakwaterowanieId);
        }
        
        [Fact]
        public void TestyZakwaterowanie()
        {
            var zakwaterowanieList = _context.Zakwaterowanie.ToList();
            
            Assert.Equal(1, zakwaterowanieList[0].ZakwaterowanieId);
            Assert.Equal(2, zakwaterowanieList[1].ZakwaterowanieId);

            Assert.Equal(1, zakwaterowanieList[0].AdresId);
            Assert.Equal(2, zakwaterowanieList[1].AdresId);
            
            Assert.Equal("Super fajny hotel", zakwaterowanieList[0].Nazwa);
            Assert.Equal("Gdzieś na odludziu", zakwaterowanieList[1].Nazwa);
            
            Assert.Equal(Typ.Hotel, zakwaterowanieList[0].Typ);
            Assert.Equal(Typ.Camping, zakwaterowanieList[1].Typ);
        }
    }
}